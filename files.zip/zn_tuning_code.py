import numpy as np
import control as ct
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ============================================================
# SYSTEM SETUP
# ============================================================
m = 0.462; g = 9.81; d = 0.42; delta = 0.65
R = 2200.0; L0 = 0.125; L1 = 0.0241; alpha = 1.2
c = 6.811e-3; k = 1885.0; b = 10.4
phi = np.radians(41); tau_m = 0.030

x1_eq = 0.5; x2_eq = 0; x4_eq = 0.5
force = k*(x1_eq - d) - m*g*np.sin(phi)
x3_eq = (delta - x1_eq) * np.sqrt(force / c)
L_eq = L0 + L1 * np.exp(-alpha * (delta - x1_eq))

A = np.zeros((4,4))
A[0,1] = 1.0
A[1,0] = (1/(1.4*m)) * (2*c*x3_eq**2/(delta-x1_eq)**3 - k)
A[1,1] = -b/(1.4*m)
A[1,2] = (2*c*x3_eq) / (1.4*m*(delta-x1_eq)**2)
A[2,2] = -R/L_eq
A[3,0] = 1/tau_m
A[3,3] = -1/tau_m

B = np.zeros((4,1))
B[2,0] = 1/L_eq
C = np.array([[0,0,0,1]])
D = np.array([[0]])

sys_ss = ct.ss(A, B, C, D)
G = ct.ss2tf(sys_ss)
s = ct.TransferFunction.s

# ============================================================
# METHOD 1: Z-N STEP RESPONSE (REACTION CURVE) METHOD
# ============================================================
# Since the plant is open-loop unstable, we first stabilise with
# a proportional controller, then extract the reaction curve parameters

Kp_stab = 25000
G_stab = ct.feedback(Kp_stab * G, 1, sign=-1)

t_step = np.linspace(0, 3, 5000)
t_s, y_s = ct.step_response(G_stab, T=t_step)
y_ss = y_s[-1]

# Tangent at maximum slope (inflection point)
dy = np.gradient(y_s, t_s)
idx_max = np.argmax(dy)
slope = dy[idx_max]
t_inf = t_s[idx_max]
y_inf = y_s[idx_max]

# Dead time L and time constant T from tangent line
L_zn = max(t_inf - y_inf / slope, 0.001)
T_zn = (y_ss - y_inf) / slope + t_inf - L_zn

print("="*55)
print("METHOD 1: Z-N STEP RESPONSE")
print("="*55)
print(f"Dead time L = {L_zn:.4f} s")
print(f"Time constant T = {T_zn:.4f} s")

# Z-N PID rules preserve the RATIO Ti = 2L, Td = 0.5L
Ti_ratio = 2.0 * L_zn   # integral time
Td_ratio = 0.5 * L_zn   # derivative time

# Search for Kp that gives ~50% overshoot while keeping Z-N ratios
print(f"Z-N ratio: Ti = {Ti_ratio:.4f}, Td = {Td_ratio:.4f}")
print("Searching for Kp to achieve ~50% overshoot...")

best1 = None
for Kp_try in np.arange(10000, 120000, 500):
    Ki_try = Kp_try / Ti_ratio
    Kd_try = Kp_try * Td_ratio
    C_try = Kp_try + Ki_try/s + Kd_try*s
    T_try = ct.feedback(C_try * G, 1, sign=-1)
    if all(np.real(ct.poles(T_try)) < -0.1):
        t_t, y_t = ct.step_response(T_try, T=np.linspace(0,3,1000))
        os_val = (max(y_t)/y_t[-1] - 1) * 100 if y_t[-1] > 0.5 else 999
        if best1 is None or abs(os_val - 50) < abs(best1[3] - 50):
            best1 = (Kp_try, Ki_try, Kd_try, os_val)

Kp_zn1, Ki_zn1, Kd_zn1, os_zn1 = best1
C_zn1 = Kp_zn1 + Ki_zn1/s + Kd_zn1*s
T_zn1 = ct.feedback(C_zn1 * G, 1, sign=-1)
print(f"\nResult: Kp = {Kp_zn1:.0f}, Ki = {Ki_zn1:.0f}, Kd = {Kd_zn1:.1f}")
print(f"Overshoot = {os_zn1:.1f}%")

# ============================================================
# METHOD 2: Z-N ULTIMATE SENSITIVITY METHOD  
# ============================================================
print("\n" + "="*55)
print("METHOD 2: Z-N ULTIMATE SENSITIVITY")
print("="*55)

# Sweep proportional gain to find Ku (marginal stability)
Kp_vals = np.linspace(1000, 200000, 10000)
rightmost = np.zeros(len(Kp_vals))

for i, Kp_test in enumerate(Kp_vals):
    p = ct.poles(ct.feedback(Kp_test * G, 1, sign=-1))
    p_slow = p[np.abs(np.real(p)) < 5000]
    rightmost[i] = max(np.real(p_slow)) if len(p_slow) > 0 else np.nan

# Find where dominant pole crosses imaginary axis
Ku = None
for i in range(len(rightmost)-1):
    if rightmost[i] > 0 and rightmost[i+1] <= 0:
        frac = rightmost[i] / (rightmost[i] - rightmost[i+1])
        Ku = Kp_vals[i] + frac * (Kp_vals[i+1] - Kp_vals[i])
        break

print(f"Ultimate Gain Ku = {Ku:.1f}")

# Find Tu: simulate at Ku and measure oscillation period
# Use a gain slightly above Ku to get observable oscillations
T_osc = ct.feedback((Ku * 1.05) * G, 1, sign=-1)
t_osc_sim = np.linspace(0, 20, 10000)
t_osc, y_osc = ct.step_response(T_osc, T=t_osc_sim)

# Find oscillation period from zero crossings of (y - mean)
y_centered = y_osc - np.mean(y_osc[-len(y_osc)//2:])
crossings = np.where(np.diff(np.sign(y_centered)))[0]
if len(crossings) >= 3:
    periods = np.diff(t_osc[crossings[1::2]])  # full periods
    Tu = np.mean(periods) if len(periods) > 0 else np.mean(np.diff(t_osc[crossings]))*2
else:
    # Fallback: use poles
    p_ku = ct.poles(ct.feedback((Ku*1.2)*G, 1, sign=-1))
    complex_p = p_ku[np.abs(np.imag(p_ku)) > 0.1]
    complex_p = complex_p[np.abs(np.real(complex_p)) < 1000]
    if len(complex_p) > 0:
        Tu = 2*np.pi/np.abs(np.imag(complex_p[0]))
    else:
        Tu = 1.0

print(f"Ultimate Period Tu = {Tu:.4f} s")

# Z-N PID rules
Kp_zn2_raw = 0.6 * Ku
Ti_zn2 = 0.5 * Tu
Td_zn2 = 0.125 * Tu

print(f"\nRaw Z-N: Kp={Kp_zn2_raw:.0f}, Ti={Ti_zn2:.4f}, Td={Td_zn2:.4f}")

# Search around Z-N ratios for best performance
best2 = None
for Kp_try in np.arange(5000, 80000, 500):
    Ki_try = Kp_try / Ti_zn2
    Kd_try = Kp_try * Td_zn2
    C_try = Kp_try + Ki_try/s + Kd_try*s
    T_try = ct.feedback(C_try * G, 1, sign=-1)
    if all(np.real(ct.poles(T_try)) < -0.1):
        t_t, y_t = ct.step_response(T_try, T=np.linspace(0,5,1000))
        final = y_t[-1]
        if abs(final - 1.0) < 0.05:  # must settle near 1
            os_val = (max(y_t)/final - 1) * 100
            if best2 is None or abs(os_val - 40) < abs(best2[3] - 40):
                best2 = (Kp_try, Ki_try, Kd_try, os_val)

if best2:
    Kp_zn2, Ki_zn2, Kd_zn2, os_zn2 = best2
else:
    # If ratio doesn't yield good DC gain, adjust Ti
    print("Adjusting Ti for better steady-state...")
    for Ti_mult in [0.2, 0.3, 0.5, 0.7, 1.0]:
        Ti_adj = Ti_zn2 * Ti_mult
        for Kp_try in np.arange(10000, 60000, 1000):
            Ki_try = Kp_try / Ti_adj
            Kd_try = Kp_try * Td_zn2
            C_try = Kp_try + Ki_try/s + Kd_try*s
            T_try = ct.feedback(C_try * G, 1, sign=-1)
            if all(np.real(ct.poles(T_try)) < -0.1):
                t_t, y_t = ct.step_response(T_try, T=np.linspace(0,5,1000))
                final = y_t[-1]
                if abs(final - 1.0) < 0.05:
                    os_val = (max(y_t)/final - 1) * 100
                    if best2 is None or abs(os_val - 40) < abs(best2[3] - 40):
                        best2 = (Kp_try, Ki_try, Kd_try, os_val)
        if best2:
            break
    Kp_zn2, Ki_zn2, Kd_zn2, os_zn2 = best2

C_zn2 = Kp_zn2 + Ki_zn2/s + Kd_zn2*s
T_zn2 = ct.feedback(C_zn2 * G, 1, sign=-1)
print(f"Result: Kp = {Kp_zn2:.0f}, Ki = {Ki_zn2:.0f}, Kd = {Kd_zn2:.1f}")
print(f"Overshoot = {os_zn2:.1f}%")

# ============================================================
# MANUAL TUNING
# ============================================================
Kp_man, Ki_man, Kd_man = 25000, 26000, 475
C_man = Kp_man + Ki_man/s + Kd_man*s
T_man = ct.feedback(C_man * G, 1, sign=-1)

# ============================================================
# DISTURBANCE REJECTION TFs:  Y/D = G / (1 + C*G)
# ============================================================
S_zn1 = ct.feedback(G, C_zn1, sign=-1)
S_zn2 = ct.feedback(G, C_zn2, sign=-1)
S_man = ct.feedback(G, C_man, sign=-1)

# ============================================================
# PERFORMANCE METRICS
# ============================================================
def metrics(t, y, name):
    final = y[-1]
    peak = max(y)
    os_pct = (peak/final - 1)*100 if final > 0.5 else float('inf')
    # Rise time (10% to 90%)
    try:
        t10 = t[np.where(y >= 0.1*final)[0][0]]
        t90 = t[np.where(y >= 0.9*final)[0][0]]
        tr = t90 - t10
    except:
        tr = float('inf')
    # Settling time (2% band)
    idx = np.where(np.abs(y - final) > 0.02*abs(final))[0]
    ts = t[idx[-1]] if len(idx) > 0 else 0
    print(f"  {name:<28} OS={os_pct:>6.1f}%  Tr={tr:.3f}s  Ts={ts:.3f}s  SS={final:.4f}")
    return os_pct, tr, ts

t_sim = np.linspace(0, 4, 3000)
t1, y1 = ct.step_response(T_zn1, T=t_sim)
t2, y2 = ct.step_response(T_zn2, T=t_sim)
t3, y3 = ct.step_response(T_man, T=t_sim)

print("\n" + "="*55)
print("PERFORMANCE COMPARISON")
print("="*55)
m1 = metrics(t1, y1, "Z-N Step Response")
m2 = metrics(t2, y2, "Z-N Ultimate Sensitivity")
m3 = metrics(t3, y3, "Manual Tuning")

# ============================================================
# FIGURE
# ============================================================
fig, axes = plt.subplots(2, 3, figsize=(18, 10))

# Row 1: Individual step responses
for ax, t, y, name, kp, ki, kd, col in [
    (axes[0,0], t1, y1, 'Z-N Step Response', Kp_zn1, Ki_zn1, Kd_zn1, 'tab:blue'),
    (axes[0,1], t2, y2, 'Z-N Ultimate Sensitivity', Kp_zn2, Ki_zn2, Kd_zn2, 'tab:green'),
    (axes[0,2], t3, y3, 'Manual Tuning', Kp_man, Ki_man, Kd_man, 'tab:purple'),
]:
    ax.plot(t, y, color=col, linewidth=2, label='Response')
    ax.axhline(1.0, color='r', linestyle='--', alpha=0.7, label='Setpoint')
    os_pct = (max(y)/y[-1] - 1)*100
    idx_s = np.where(np.abs(y - y[-1]) > 0.02*abs(y[-1]))[0]
    ts = t[idx_s[-1]] if len(idx_s) > 0 else 0
    ax.set_title(f'{name}\nKp={kp:.0f}, Ki={ki:.0f}, Kd={kd:.0f}\nOS={os_pct:.1f}%, Ts={ts:.2f}s')
    ax.set_xlabel('Time (s)')
    ax.set_ylabel(r'$\Delta x$')
    ax.grid(True, linestyle='--')
    ax.legend(fontsize=9)

# Row 2, Col 1: Ultimate gain search
axes[1,0].plot(Kp_vals, rightmost, 'b-', linewidth=1.5)
axes[1,0].axhline(0, color='r', linestyle='--')
axes[1,0].axvline(Ku, color='green', linestyle=':', linewidth=2, label=f'Ku = {Ku:.0f}')
axes[1,0].fill_between(Kp_vals, rightmost, 0, where=(rightmost > 0), alpha=0.1, color='red')
axes[1,0].set_title('Ultimate Gain Search\n(Rightmost pole real part vs Kp)')
axes[1,0].set_xlabel('Proportional Gain Kp')
axes[1,0].set_ylabel('Re(dominant pole)')
axes[1,0].grid(True, linestyle='--')
axes[1,0].legend()
axes[1,0].set_ylim([-15, 10])

# Row 2, Col 2: Disturbance rejection
t_dist = np.linspace(0, 4, 3000)
for S_tf, name, col in [
    (S_zn1, 'Z-N Step Resp.', 'tab:blue'),
    (S_zn2, 'Z-N Ult. Sens.', 'tab:green'),
    (S_man, 'Manual', 'tab:purple'),
]:
    td, yd = ct.step_response(S_tf, T=t_dist)
    axes[1,1].plot(td, yd, color=col, linewidth=2, label=name)
axes[1,1].axhline(0, color='k', linewidth=0.5)
axes[1,1].set_title('Disturbance Rejection\n(Response to step disturbance at plant input)')
axes[1,1].set_xlabel('Time (s)')
axes[1,1].set_ylabel('Output deviation')
axes[1,1].grid(True, linestyle='--')
axes[1,1].legend(fontsize=9)

# Row 2, Col 3: All overlaid
axes[1,2].plot(t1, y1, 'tab:blue', linewidth=2, label='Z-N Step Response')
axes[1,2].plot(t2, y2, 'tab:green', linewidth=2, label='Z-N Ultimate Sensitivity')
axes[1,2].plot(t3, y3, 'tab:purple', linewidth=2, label='Manual Tuning')
axes[1,2].axhline(1.0, color='r', linestyle='--', alpha=0.7)
axes[1,2].set_title('All Methods Compared')
axes[1,2].set_xlabel('Time (s)')
axes[1,2].set_ylabel(r'$\Delta x$')
axes[1,2].grid(True, linestyle='--')
axes[1,2].legend(fontsize=9)

plt.suptitle('Ziegler-Nichols PID Tuning - Magnetic Levitation System',
             fontsize=14, fontweight='bold')
plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/zn_tuning_comparison.png', dpi=150, bbox_inches='tight')
print("\nFigure saved!")

# Print final summary table
print("\n" + "="*55)
print("FINAL PID PARAMETERS")
print("="*55)
print(f"{'Method':<28} {'Kp':>8} {'Ki':>8} {'Kd':>8}")
print("-"*55)
print(f"{'Z-N Step Response':<28} {Kp_zn1:>8.0f} {Ki_zn1:>8.0f} {Kd_zn1:>8.0f}")
print(f"{'Z-N Ultimate Sensitivity':<28} {Kp_zn2:>8.0f} {Ki_zn2:>8.0f} {Kd_zn2:>8.0f}")
print(f"{'Manual Tuning':<28} {Kp_man:>8} {Ki_man:>8} {Kd_man:>8}")

